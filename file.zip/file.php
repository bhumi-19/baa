<?php
include "../phpcode/confi.php";
?>
<?php include "./head.php"?>
<?php
if(isset($_POST['prosub'])){
    $n=$_POST['pn'];
    $c=$_POST['pc'];
    $p=$_POST['pi'];
    $q=$_POST['qt'];
    $d=$_POST['de'];
    $filenm=$_FILES['file']['name'];
    $basenm=substr($filenm,0,strripos($filenm,'.'));
    $ext=substr($filenm,strripos($filenm,'.'));
    $tmpnm=$_FILES['file']['tmp_name'];
    $alowtyp=array(".jpg",".png");
    if(in_array($ext,$alowtyp)){
        $newfilenm=md5($basenm).rand(10,1000).time().$ext;
        if(file_exists("upload/".$newfilenm)){
            echo "file existst";
        }else{
            move_uploaded_file($tmpnm,"upload/".$newfilenm);
            if($n !="" && $c!="" && $p!="" && $q!="" && $d!=""){
                $ip="INSERT INTO products(pname, category, price,qty,des,proimages) VALUES
                 ('$n','$c','$p','$q','$d','$newfilenm') ";
                 $r=mysqli_query($con,$ip);
                 if($r){
                    echo "Inserted";
                 }else{
                    echo "Insertion Failed";
                 }
            }
            else{
                echo "Fiels Is Empty";
            }
        }
    }
    else{
        echo"allowed file are jpg and png";
    }
}
?>




<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="file.php" method="post" enctype="multipart/form-data">
        <input type="file" name="file">
        <br>
        <input type="text" name="pn" placeholder="Enter Product Name">
        <br>
        <input type="text" name="pc" placeholder="Enter Product Category">
        <br>
        <input type="text" name="pi" placeholder="Enter Product Price">
        <br>
        <input type="text" name="qt" placeholder="Enter Product Quantity">
        <br>
        <textarea name="de" cols="5" rows="5"   placeholder="Enter Product Description"></textarea>
        <br>
        <button type="submit" name="prosub">submit</button>
    </form>
</body>
</html> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       
        .container {
            max-width: 800px; 
            margin: 0 auto;
        }

        .card {
            margin-top: 20px; 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <strong>Add New Products</strong>
            </div>
            <div class="card-body">
            <form action="file.php" method="post" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <input type="file" name="file">
                        
                    </div>
                    <br>
                    <div class="form-group col-md-6">
                        <input type="text" name="pn" placeholder="Enter Product Name">
                       
                    </div>
                    <br>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <input type="text" name="pc" placeholder="Enter Product Category">
                       

                    </div>
                    <br>
                    <div class="form-group col-md-6">
                        <input type="text" name="pi" placeholder="Enter Product Price">
                        

                    </div>
                    <br>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <input type="text" name="qt" placeholder="Enter Product Quantity">
                       

                    </div>
                    <br>
                    <div class="form-group col-md-6">
                        <textarea name="de" cols="20" rows="5"   placeholder="Enter Product Description"></textarea>
                    </div>
                    <br>

                </div>
                <button type="submit" name="prosub">submit</button>
            </form>
            </div>
        </div>
    </div>
</body>
</html>